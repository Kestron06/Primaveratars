/**
Heavy credit is due to @Clovenbob from Khan Academy. I took inspiration from his Catageis extension and used it as a base while 
developing this one.
*/
var peeps=[
	{
		name:"Kestron",
		lvl:5,
		avatar:"hopper cool",
		team:"Terratrice",
	},
	{
		name:"LeaferStudios",
		lvl:4,
		avatar:"leafers ultimate",
		team:"Terratrice",
	},
	{
		name:"WalkWorthy",
		lvl:4,
		avatar:"leaf blue",
		team:"Terratrice",
	},
	{
		name:"𝙕𝙚 𝙍𝙚𝙙 𝘽𝙖𝙧𝙧𝙤𝙣",
		lvl:4,
		avatar:"leaf red",
		team:"Terratrice",
	},
	{
		name:"BirdySparrowCatcher",
		lvl:3,
		avatar:"duskpin sapling",
		team:"Terratrice",
	},
	{
		name:"Dominic R.",
		lvl:3,
		avatar:"sneak peak yellow",
		team:"Terratrice",
	},
	{
		name:"Heaven",
		lvl:3,
		avatar:"area 52 green",
		team:"Terratrice",
	},
	{
		name:"NamenotFound404",
		lvl:3,
		avatar:"leaf orange",
		team:"Terratrice",
	},
	{
		name:"𝕭𝐥𝐚𝐝𝐞𝐬𝐦𝐢𝐭𝐡",
		lvl:3,
		avatar:"leaf grey",
		team:"Terratrice",
	},
	{
		name:"~The Wolf~",
		lvl:3,
		avatar:"sneak peak blue",
		team:"Terratrice",
	},
	{
		name:"BrenErso",
		lvl:3,
		avatar:"leaf red",
		team:"Terratrice",
	},
	{
		name:"ami-ari",
		lvl:3,
		avatar:"blobby blue",
		team:"Terratrice",
	},
	{
		name:"PanzerSchnitter#TerratriceFTW",
		lvl:3,
		avatar:"starky ultimate",
		team:"Terratrice",
	},
	{
		name:"Canada Goose",
		lvl:2,
		avatar:"starky sapling",
		team:"Terratrice",
	},
	{
		name:"Colorful Feather😜",
		lvl:2,
		avatar:"leaf yellow",
		team:"Terratrice",
	},
	{
		name:"Cookie dough",
		lvl:2,
		avatar:"duskpin ultimate",
		team:"Terratrice",
	},
	{
		name:"CowboysFan Creations",
		lvl:2,
		avatar:"leafers ultimate",
		team:"Terratrice",
	},
	{
		name:"TDJ",
		lvl:2,
		avatar:"boggle green",
		team:"Terratrice",
	},
	{
		name:"K2",
		lvl:1,
		avatar:"sneak peak blue",
		team:"Terratrice",
	},
	{
		name:"ᴱᶜˡⁱᵖˢᵉ",
		lvl:1,
		avatar:"leaf grey",
		team:"Terratrice",
	},
	{
		name:"🐼PandaProgram🐼",
		lvl:1,
		avatar:"aqualine tree",
		team:"Terratrice",
	},
	{
		name:"Fire Wolf #Terratrice [Offline]",
		lvl:3,
		avatar:"leaf red",
		team:"Terratrice",
	},
	{
		name:"Sparky Studio🎇🎇🎇",
		lvl:1,
		avatar:"blobby blue",
		team:"Terratrice",
	},
	{
		name:"BC#TheSpringChallenges #GoTerratice",
		lvl:1,
		avatar:"leaf green",
		team:"Terratrice",
	},
	{
		name:"Hurtin #Pyroach",
		lvl:5,
		avatar:"leaf green",
		team:"Pyroach",
	},
	{
		name:"ΛGΞПТ Ж",
		lvl:4,
		avatar:"starky sapling",
		team:"Pyroach",
	},
	{
		name:":/",
		lvl:4,
		avatar:"winston baby",
		team:"Pyroach",
	},
	{
		name:"Kirby Kid",
		lvl:1,
		avatar:"primosaur tree",
		team:"Pyroach",
	},
	{
		name:"Triumvirate Softworks",
		lvl:4,
		avatar:"leaf green",
		team:"Pyroach",	
	},
	{
		name:"The Blue Axolotl #Pyroach",
		lvl:3,
		avatar:"spunky sam blue",
		team:"Pyroach",
	},
	{
		name:"21262",
		lvl:3,
		avatar:"boggle blue",
		team:"Pyroach",
	},
	{
		name:"Lemon Games #Pyroach",
		lvl:3,
		avatar:"leaf yellow",
		team:"Pyroach",
	},
	{
		name:"Mine300#ACC",
		lvl:3,
		avatar:"piceratops ultimate",
		team:"Pyroach",
	},
	{
		name:"𝕊𝕡𝕒𝕣𝕜𝕝𝕖 𝕎𝕠𝕝𝕗",
		lvl:3,
		avatar:"duskpin seedling",
		team:"Pyroach",
	},
	{
		name:"JackCheesecake#teamPyroach",
		lvl:3,
		avatar:"winston default",
		team:"Pyroach",
	},
	{
		name:"Jay6000",
		lvl:3,
		avatar:"hopper cool",
		team:"Pyroach",
	},
	{
		name:"F4stB01 #Pyroach",
		lvl:3,
		avatar:"hopper cool",
		team:"Pyroach",
	},
	{
		name:"XEC32 #pyroach",
		lvl:3,
		avatar:"piceratops ultimate",
		team:"Pyroach",
	},
	{
		name:"Pompano #pyroach",
		lvl:2,
		avatar:"eggleston yellow",
		team:"Pyroach",
	},
	{
		name:"Incognito_AI",
		lvl:2,
		avatar:"male robot donald",
		team:"Pyroach",
	},
	{
		name:"Ameer Nahhas #Pyroach",
		lvl:2,
		avatar:"duskpin ultimate",
		team:"Pyroach",
	},
	{
		name:"𝕄𝕒𝕣𝕚𝕠𝕏 😀 #pyroach",
		lvl:2,
		avatar:"piceratops ultimate",
		team:"Pyroach",
	},
	{
		name:"𝓛𝓾𝓷𝓪𝓻 𝓦𝓸𝓵𝓯𝓲𝓮",
		lvl:2,
		avatar:"duskpin ultimate",
		team:"Pyroach",
	},
	{
		name:"Alex M. #pyroach",
		lvl:1,
		avatar:"piceratops seed",
		team:"Pyroach",	
	},
	{
		name:"deepulachu",
		lvl:1,
		avatar:"leaf red",
		team:"Pyroach",
	},

	{
		name:"Gray Phantom",
		lvl:4,
		avatar:"starky ultimate",
		team:"Buzzaw",
	},
	{
		name:"PT",
		lvl:4,
		avatar:"area 52 yellow",
		team:"Buzzaw",
	},
	{
		name:"NL#Midsane",
		lvl:3,
		avatar:"duskpin seedling",
		team:"Buzzaw",
	},
	{
		name:"Mandalore the Great #UnbanIA",
		lvl:3,
		avatar:"leaf blue",
		team:"Buzzaw",
	},
	{
		name:"Chase L.",
		lvl:3,
		avatar:"duskpin ultimate",
		team:"Buzzaw",
	},
	{
		name:"tzviofen #Buzzaw",
		lvl:3,
		avatar:"aqualine ultimate",
		team:"Buzzaw",
	},
	{
		name:"The No-Sock Guy(alt)",
		lvl:3,
		avatar:"starky seed",
		team:"Buzzaw",
	},
	{
		name:"The Blue Pineapple",
		lvl:3,
		avatar:"starky ultimate",
		team:"Buzzaw",
	},
	{
		name:"Diamond Programmer",
		lvl:3,
		avatar:"leaf blue",
		team:"Buzzaw",
	},
	{
		name:"Dipper98",
		lvl:3,
		avatar:"hopper jumping",
		team:"Buzzaw",
	},
	{
		name:"Kineto #Buzzaw",
		lvl:2,
		avatar:"aqualine ultimate",
		team:"Buzzaw",
	},
	{
		name:"ĴΔĆØβ ŞŴΔŇŦØŇ",
		lvl:2,
		avatar:"aqualine sapling",
		team:"Buzzaw",
	},
	{
		name:"Digitsofpi #teambuzzaw",
		lvl:2,
		avatar:"leaf red",
		team:"Buzzaw",
	},
	{
		name:"Darth Pastry",
		lvl:2,
		avatar:"female robot ada",
		team:"Pyroach",
	},
	{
		name:"🔥Fire Falchion🔥",
		lvl:2,
		avatar:"piceratops sapling",
		team:"Buzzaw",
	},
	{
		name:"marci (read bio)",
		lvl:1,
		avatar:"leafers seedling",
		team:"Buzzaw",
	},
	{
		name:"Developer",
		lvl:1,
		avatar:"leaf blue",
		team:"Buzzaw",
	},
	{
		name:"👑 The King Loco 👑",
		lvl:1,
		avatar:"stelly green",
		team:"Buzzaw",
	},
	{
		name:"Ivan #TeamBuzzaw",
		lvl:1,
		avatar:"hopper cool",
		team:"Buzzaw",
	},
	{
		name:"Sinalle",
		lvl:2,
		avatar:"female robot ada",
		team:"Terratrice",
	},

	{
		name:"DauntlessStudios",
		lvl:4,
		avatar:"hopper cool",
		team:"Cloudlark",
	},
	{
		name:"Leaf",
		lvl:4,
		avatar:"leaf grey",
		team:"Cloudlark",
	},
	{
		name:"Timothy Kostenko Productions #TKP FTW",
		lvl:4,
		avatar:"male robot donald",
		team:"Cloudlark",
	},
	{
		name:"Virtuosa",
		lvl:3,
		avatar:"duskpin seedling",
		team:"Cloudlark",
	},
	{
		name:"Captain Longtreader",
		lvl:3,
		avatar:"starky sapling",
		team:"Cloudlark",
	},
	{
		name:"SomeRandomUsername #TeamCloudlark",
		lvl:3,
		avatar:"winston baby",
		team:"Cloudlark",
	},
	{
		name:"Kopter Coding",
		lvl:3,
		avatar:"leaf blue",
		team:"Cloudlark",
	},
	{
		name:"Andrew Killillay",
		lvl:3,
		avatar:"old spice man green",
		team:"Cloudlark",
	},
	{
		name:"Kim, Gavin",
		lvl:3,
		avatar:"starky tree",
		team:"Cloudlark",
	},
	{
		name:"Masqueet",
		lvl:3,
		avatar:"aqualine sapling",
		team:"Cloudlark",
	},
	{
		name:"Dark Feather",
		lvl:2,
		avatar:"duskpin ultimate",
		team:"Cloudlark",
	},
	{
		name:"Blue Pickle",
		lvl:3,
		avatar:"hopper jumping",
		team:"Cloudlark",
	},
	{
		name:"Anton Logathro #Cloudlark",
		lvl:2,
		avatar:"piceratops ultimate",
		team:"Cloudlark",
	},
	{
		name:"Frog Productions #CLOUDLARK",
		lvl:2,
		avatar:"leaf blue",
		team:"Cloudlark",	
	},
	{
		name:"luwagga",
		lvl:2,
		avatar:"winston baby",
		team:"Cloudlark",
	},
	{
		name:"🎺doot doot🎺#teamcloudlark",
		lvl:2,
		avatar:"starky ultimate",
		team:"Cloudlark",
	},
	{
		name:"Nemo",
		lvl:1,
		avatar:"leaf orange",
		team:"Cloudlark",
	},
	{
		name:"sgh07",
		lvl:1,
		avatar:"stelly orange",
		team:"Cloudlark",
	},
	{
		name:"Samwise #JesusIsKing",
		lvl:1,
		avatar:"leafers tree",
		team:"Cloudlark",
	},

	{
		name:"ski",
		lvl:5,
		avatar:"starky sapling",
		team:"Mountaintop",
	},
	{
		name:"SP",
		lvl:4,
		avatar:"leaf yellow",
		team:"Mountaintop",
	},
	{
		name:"jmtyk",
		lvl:4,
		avatar:"duskpin ultimate",
		team:"Mountaintop",
	},
	{
		name:"🐓ƬHƎ CHICKƎӤ LOƦD🐔",
		lvl:4,
		avatar:"starky ultimate",
		team:"Mountaintop",
	},
	{
		name:"𝔗𝔐ℌ",
		lvl:4,
		avatar:"leaf blue",
		team:"Mountaintop",
	},
	{
		name:"nathanTiPrograming",
		lvl:3,
		avatar:"hopper cool",
		team:"Mountaintop",
	},
	{
		name:"NinjaX",
		lvl:3,
		avatar:"starky seed",
		team:"Mountaintop",
	},
	{
		name:"BoredBetryedme#MountainTopFTW",
		lvl:3,
		avatar:"sneak peak purple",
		team:"Mountaintop",
	},
	{
		name:"ŁąƶƹřŁƹǥƹɲȡ ¥ ȿ #Rl #TM",
		lvl:3,
		avatar:"sneak peak blue",
		team:"Mountaintop",
	},
	{
		name:"Vfd Ftgcykg",
		lvl:3,
		avatar:"area 52 blue",
		team:"Mountaintop",
	},
	{
		name:"PiCera",
		lvl:3,
		avatar:"blobby blue",
		team:"Mountaintop",
	},
	{
		name:"PK",
		lvl:3,
		avatar:"blobby yellow",
		team:"Mountaintop",
	},
	{
		name:"𝔽𝕒𝕚𝕥𝕙",
		lvl:3,
		avatar:"piceratops sapling",
		team:"Mountaintop",
	},
	{
		name:"Ferr",
		lvl:2,
		avatar:"hopper jumping",
		team:"Mountaintop",
	},
	{
		name:"Noisy #goMountaintop",
		lvl:2,
		avatar:"duskpin tree",
		team:"Mountaintop",
	},
	{
		name:"Polar",
		lvl:2,
		avatar:"hopper cool",
		team:"Mountaintop",
	},
	{
		name:"Golden Orange #MountaintopFTW",
		lvl:2,
		avatar:"hopper cool",
		team:"Mountaintop",
	},
	{
		name:"NHBubba#JesusIsKing",
		lvl:2,
		avatar:"ohnoes default",
		team:"Mountaintop",
	},
	{
		name:"CalvinatorIA",
		lvl:1,
		avatar:"hopper cool",
		team:"Mountaintop",
	},
	{
		name:"DudeCoolDJE",
		lvl:1,
		avatar:"male robot donald",
		team:"Mountaintop",
	},
	{
		name:"ÐoɠIovɛɼ",
		lvl:1,
		avatar:"leaf red",
		team:"Mountaintop",
	},
	{
		name:"Abacaba",
		lvl:1,
		avatar:"cacteye green",
		team:"Mountaintop",
	},

	{
		name:"Blaze Programming",
		lvl:5,
		avatar:"leaf blue",
		team:"Icicle",
	},
	{
		name:"Ⲧⲏⲉ_Ⲣⲁꞅⲁⲇⲟⲭ",
		lvl:4,
		avatar:"winston baby",
		team:"Icicle",
	},
	{
		name:"Sunny Starlight ッ",
		lvl:4,
		avatar:"piceratops ultimate",
		team:"Icicle",
	},
	{
		name:"QuasarBlast",
		lvl:4,
		avatar:"primosaur seed",
		team:"Icicle",
	},
	{
		name:"Doctor137",
		lvl:4,
		avatar:"orange juice squid",
		team:"Icicle",
	},
	{
		name:"XRWatkins",
		lvl:4,
		avatar:"starky ultimate",
		team:"Icicle",
	},
	{
		name:"ŊØĄĦ ŠŴÄŊŦØŃ",
		lvl:3,
		avatar:"winston baby",
		team:"Icicle",
	},
	{
		name:"Mr. Winston™",
		lvl:3,
		avatar:"winston default",
		team:"Icicle",
	},
	{
		name:"VanadiumDev #IcicleFTW",
		lvl:3,
		avatar:"leaf blue",
		team:"Icicle",
	},
	{
		name:"ッ Coder ッ",
		lvl:3,
		avatar:"hopper cool",
		team:"Icicle",
	},
	{
		name:"WinstonWinner000",
		lvl:3,
		avatar:"winston default",
		team:"Icicle",
	},
	{
		name:"⭐Finn_Pb🔥#icicleFTW",
		lvl:3,
		avatar:"starky tree",
		team:"Icicle",
	},
	{
		name:"Shadow #BadPunsArmy#BringBackBackrounds",
		lvl:3,
		avatar:"starky tree",
		team:"Icicle",
	},
	{
		name:"𝗧𝗵𝗲 𝗟𝗶𝗰𝗵 𝗞𝗶𝗻𝗴",
		lvl:3,
		avatar:"male robot donald",
		team:"Icicle",
	},
	{
		name:"Prometheus #IcicleFTW",
		lvl:3,
		avatar:"aqualine ultimate",
		team:"Icicle",
	},
	{
		name:"SkyCloud #IcicleFTW",
		lvl:2,
		avatar:"stelly blue",
		team:"Icicle",
	},
	{
		name:"GamerZ3000",
		lvl:2,
		avatar:"primosaur tree",
		team:"Icicle",
	},
	{
		name:"∫ŞÃÃČ ŞŴÄŇŢ⊕Ŋ",
		lvl:2,
		avatar:"leaf grey",
		team:"Icicle",
	},
	{
		name:"ΡΙΧΕLBlΘΧ-STשDIOS#Go Team 🧊",
		lvl:2,
		avatar:"aqualine ultimate",
		team:"Icicle",
	},
	{
		name:"aeych‭",
		lvl:2,
		avatar:"mr pants teal",
		team:"Icicle",
	},
	{
		name:"Candle🕯️Light Studios",
		lvl:2,
		avatar:"starky sapling",
		team:"Icicle",
	},
	{
		name:"stuff",
		lvl:1,
		avatar:"ohnoes default",
		team:"Icicle",	
	},
	{
		name:"Fade#IcicleFTW",
		lvl:1,
		avatar:"starky ultimate",
		team:"Icicle",
	},
	{
		name:"Annabanana07",
		lvl:1,
		avatar:"primosaur sapling",
		team:"Icicle",
	},

	{
		name:"Liam K.",
		lvl:5,
		avatar:"duskpin ultimate",
		team:"Judge",
	},
	{
		name:"SpencerKuan",
		lvl:4,
		avatar:"leaf orange",
		team:"Judge",
	},
	{
		name:"JSCoder",
		lvl:4,
		avatar:"leaf orange",
		team:"Judge",
	},
	{
		name:"CoraL",
		lvl:4,
		avatar:"sneak peak purple",
		team:"Judge",
	},
	{
		name:"LC [PRIMAVERA JUDGE]",
		lvl:4,
		avatar:"area 52 yellow",
		team:"Judge",
	},
	{
		name:"‭‮siuqilA",
		lvl:4,
		avatar:"aqualine ultimate",
		team:"Judge",
	},
	{
		name:"CtmGamer",
		lvl:4,
		avatar:"scuttlebug blue",
		team:"Judge",
	},
	{
		name:"Liftoff Studios",
		lvl:4,
		avatar:"starky ultimate",
		team:"Judge",
	},
	{
		name:"ℂ𝕠𝕣𝕚𝕟 𝔽𝕚𝕤𝕥",
		lvl:4,
		avatar:"primosaur tree",
		team:"Judge",
	},
	{
		name:"FifthStateOfMatter #GoTeamBob",
		lvl:4,
		avatar:"leaf blue",
		team:"Judge",
	},
	{
		name:"𝕱𝖑𝖚𝖝 [Primavera Judge]",
		lvl:4,
		avatar:"starky seedling",
		team:"Judge",
	},

	{
		name:"Paperwad",
		lvl:4,
		avatar:"orange juice squid",
		team:"Terratrice",
	},
];
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
	  replaceAvatar("avatar-pic");
	  replaceAvatar("_9phhti");
	  replaceAvatar("_1u01yeu");
  });
window.setInterval(replaceAvatar,10000);
function replaceAvatar(className) {
	var avatarElements = document.getElementsByClassName(className);
	//Create a dummy tag to prevent errors
	var dummy=document.createElement("span");
	dummy.setAttribute("class","_o77ufew");
	document.getElementById("page-container").appendChild(dummy);
	var curName=document.querySelector("._o77ufew").innerHTML;
	var i;
	for (i = 0; i < avatarElements.length; i++) {
	  var a=avatarElements[i];
	  var j;
	  for(j=0;j<peeps.length;j++){
		if(a.alt.toLowerCase()===peeps[j].avatar+' style avatar for user '+peeps[j].name.toLowerCase()||curName===peeps[j].name){
			if(peeps[j].team==="Terratrice"){
				if(peeps[j].lvl===5){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-terratrice/5962079136202752/latest.png";
				}
				if(peeps[j].lvl===4){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-terratrice/5499167546851328/latest.png";
				}
				if(peeps[j].lvl===3){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-terratrice/4523887042805760/latest.png";
				}
				if(peeps[j].lvl===2){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-terratrice/5390901286322176/latest.png";
				}
				if(peeps[j].lvl===1){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-terratrice/5487392290029568/latest.png";
				}
			}

			if(peeps[j].team==="Pyroach"){
				if(peeps[j].lvl===5){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-pyroach/5682783170117632/latest.png";
				}
				if(peeps[j].lvl===4){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-pyroach/4751334149505024/latest.png";
				}
				if(peeps[j].lvl===3){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-pyroach/4984313234898944/latest.png";
				}
				if(peeps[j].lvl===2){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-pyroach/5769125233213440/latest.png";
				}
				if(peeps[j].lvl===1){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-pyroach/5299648263667712/latest.png";
				}
			}
			if(peeps[j].team==="Buzzaw"){
				if(peeps[j].lvl===5){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-buzzaw/5885499318255616/latest.png";
				}
				if(peeps[j].lvl===4){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-buzzaw/6192871001604096/latest.png";
				}
				if(peeps[j].lvl===3){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-buzzaw/5323912882733056/latest.png";
				}
				if(peeps[j].lvl===2){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-buzzaw/5272137119088640/latest.png";
				}
				if(peeps[j].lvl===1){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-buzzaw/4547885642334208/latest.png";
				}
			}

			if(peeps[j].team==="Cloudlark"){
				if(peeps[j].lvl===5){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-cloudlark/6521652627161088/latest.png";
				}
				if(peeps[j].lvl===4){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-cloudlark/5621130390978560/latest.png";
				}
				if(peeps[j].lvl===3){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-cloudlark/5655810299445248/latest.png";
				}
				if(peeps[j].lvl===2){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-cloudlark/6679647025676288/latest.png";
				}
				if(peeps[j].lvl===1){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-cloudlark/5859224721604608/latest.png";
				}
			}

			if(peeps[j].team==="Mountaintop"){
				if(peeps[j].lvl===5){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-mountaintop/6081598129750016/latest.png";
				}
				if(peeps[j].lvl===4){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-mountaintop/4846611355189248/latest.png";
				}
				if(peeps[j].lvl===3){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-mountaintop/4516922411499520/latest.png";
				}
				if(peeps[j].lvl===2){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-mountaintop/5080810077077504/latest.png";
				}
				if(peeps[j].lvl===1){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-mountaintop/6248793421955072/latest.png";
				}
			}

			if(peeps[j].team==="Icicle"){
				if(peeps[j].lvl===5){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-icicle/4834125616824320/latest.png";
				}
				if(peeps[j].lvl===4){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-icicle/5924358504628224/latest.png";
				}
				if(peeps[j].lvl===3){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-icicle/5819298168750080/latest.png";
				}
				if(peeps[j].lvl===2){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-icicle/4701002367287296/latest.png";
				}
				if(peeps[j].lvl===1){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-icicle/4790565790072832/latest.png";
				}
			}

			if(peeps[j].team==="Judge"){
				if(peeps[j].lvl===5){}
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-cataegis-the-great-whirlwind-official-entry/5120079835480064/latest.png";
				}
				if(peeps[j].lvl===4&&peeps[j].team==="Judge"){
					avatarElements[i].src="https://www.khanacademy.org/computer-programming/spin-off-of-cataegis-the-great-whirlwind-official-entry/5687537698914304/latest.png";
				}
			}
		}
	}
}

	

